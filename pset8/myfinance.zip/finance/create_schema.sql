-- create schhema for finance db
-- k r bergerstock @ 2020-12-24

-- to be used on an empty data base
-- or to reconfigure an existing db
drop table 'users';
drop table 'config';
drop table 'names';
drop table 'symbols';
drop table 'stocks';
drop table 'history';

.tables

create table if not exists 'names' ( 
        'user_id' integer not null,
        'first'   text, 
        'middle'  text, 
        'last'    text
);

create table if not exists 'symbols' (
        'symbol'   TEXT primary key NOT NULL,
        'company'  TEXT,
        'exchange' text,
        'type'     text
);

CREATE TABLE IF NOT EXISTS "stocks" (
        'user_id'   INTEGER NOT NULL,
        'symbol'    TEXT NOT NULL,
        'shares'    INTEGER DEFAULT 0,
        'invested'  REAL DEFAULT 0.0,
        'price'     REAL DEFAULT 0.0,    
        'value'     REAL DEFAULT 0.0    
);

CREATE TABLE IF NOT EXISTS "history" (
        'user_id'   INTEGER NOT NULL,
        'tdate'     TEXT NOT NULL,
        'symbol'    TEXT NOT NULL,
        'action'    TEXT NOT NULL,    
        'price'     REAL NOT NULL DEFAULT 0.0,
        'shares'    INTEGER NOT NULL DEFAULT 0,
        'cost'      REAL NOT NULL DEFAULT 0.0
);

create table if not exists "config" (
        'variable' text not null,
        'value'    text not null,     
        'type'     text not null     
        );

insert into 'config' (variable, value, type ) values('api_key','pk_34cf6f3b055e41ae89c7461648ffed73','text');

CREATE TABLE IF NOT EXISTS 'users' (
    'user_id' INTEGER PRIMARY KEY AUTOINCREMENT not null, 
    'username' TEXT NOT NULL, 
    'hash' TEXT NOT NULL, 
    'cash' NUMERIC NOT NULL DEFAULT 10000.00 
    );

CREATE UNIQUE INDEX 'username' ON "users" ("username");

.tables
