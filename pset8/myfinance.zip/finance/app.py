import os

from flask import Flask, flash, jsonify, redirect, render_template, request, g
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, usd
from financedb import financeDB
import iexapis

# Configure application
app = Flask(__name__)

#initialize the data base
db = financeDB('finance.db')
dmenu = [("/about","About"),("/register","Register"),("/login","Login")]
lmenu = dmenu
# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.before_request
def before_request():
    g.user_id = db.user_id()
    g.user_name = db.user_name()
    g.user_proper_name = db.user_proper_name()
    g.cash = db.user_cash_balance()
    return None

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# API_KEY = "pk_34cf6f3b055e41ae89c7461648ffed73"
# Make sure API key is set
""" if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set") """


@app.route('/about')            
def About():  
    return render_template("about.html",menu=[("/","Home")])


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    user_name = ''
    password = ''
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # read inpput from form
        user_name = request.form.get("username",'')
        password = request.form.get("password",'')
        # Ensure username was submitted
        if not user_name:
            return apology("must provide user name", 401)
        # Ensure password was submitted
        if not password:
            return apology("must provide password", 402)

        # Query database for username
        if db.login(user_name, password):
            # Redirect user to home page
            return redirect("/")
        return apology("invalid username and/or password", 403)
    else:
        # User reached route via GET (as by clicking a link or via redirect)
        return render_template("login.html", menu=dmenu)


@app.route("/logout")
def logout():
    """Log user out"""
    db.logout()
    # Redirect user to login form
    return redirect("/login")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    user_name = ''
    password = ''
    first = ''
    middle = ''
    last = ''
    if request.method == 'POST':
        # read the input from the form
        user_name = request.form.get('username',None)
        password = request.form.get('password',None)
        first = request.form.get('first','')
        middle = request.form.get('middle','')
        last = request.form.get('last','')
        # Ensure username was submitted
        if not user_name:
            return apology("must provide username", 401)
        # Ensure password was submitted
        if not password:
            return apology("must provide password", 402)
        # if the data base writes failed
        if not db.register(user_name, password, first, middle, last):
            return apology("register TODO") # fIX
        # Redirect user to home page
        return redirect("/")
    else:
        return render_template("register.html",menu=dmenu)


@app.route("/")
def index():
    return redirect('/portfolio')


@app.route("/portfolio",methods=["GET", "POST"])
@login_required
def portfolio():
    """<HOME> Show portfolio of stocks"""
    if request.method == 'POST':
        shares = request.form.get('shares','')
        print(shares)
        job = request.form.get('job','')
        print(job)
        if job =='quote':
            return apology("quote TODO")
        elif job == 'track':
            pass    
        elif job == 'buy':
            pass
        elif job == 'sell':
            pass
        elif job == 'delete':
            pass
        else:
            return apology("portfolio form",'undefind behavoir')
    else: 
        db.update_quote_price()
        portfolio = db.read_portfolio()
        lmenu=[("/about","About"),("/logout","Logout"),("/history","History"),("/select","Select Stock")]
        return  render_template('portfolio.html',cash = g.cash, table = portfolio, menu = lmenu)


@app.route("/history",methods=["GET", "POST"])
@login_required
def history():
    """Show history of transactions"""
    if request.method == 'POST':
        return apology("history TODO")
    else:  
        lmenu=[("/about","About"),("/logout","Logout"),("/portfolio","Portfolio"),("/select","SeLect Stock")]
        return  render_template('history.html',table = None,menu=lmenu)


@app.route("/select", methods=["GET", "POST"])
@login_required
def select():
    """Get / dispplay stock list"""
    stocks =  iexapis.fetch_symbols()
    if request.method == 'POST':  
        symbol = request.form.get('symbol')
        # get a list of the stock to quote
        stocks2quote = get_stocks2quote(stocks)
        #update data bases  
        db.update_stocks(stocks2quote)
        # return to the portfolio page
        return redirect("/portfolio")
    else:  
        lmenu = [("/about","About"),("/logout","Logout"),("/history","History"),("/portfolio","Portfolio")]
        return  render_template('select.html',stocks = stocks,menu = lmenu)  

def get_stocks2quote(stock_list):
    stocks2quote = []
    symbol = request.form.get('symbol',None)
    for item in stock_list:
        if request.form.get(item[0]) == 'on' or symbol == item[0] :
            stocks2quote.append(item)
    return stocks2quote

def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
