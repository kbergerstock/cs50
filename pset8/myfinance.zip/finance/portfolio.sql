select stocks.symbol, symbols.company,shares, invested, price , value from stocks 
    inner join symbols on stocks.symbol = symbols.symbol where user_id = 1002;